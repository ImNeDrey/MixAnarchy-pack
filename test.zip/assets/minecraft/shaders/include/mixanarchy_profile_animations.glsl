/* Profile covers 32, 33, 34. GameTime is the vanilla normalized day fraction. */
const int FT_32_DURATIONS[17] = int[17](40,40,50,40,40,40,40,40,50,40,40,40,40,40,50,40,40);
int ft_32_frame() {
    float t = mod(GameTime * 1200000.0, 710.0);
    for (int i = 0; i < 17; ++i) {
        t -= float(FT_32_DURATIONS[i]);
        if (t < 0.0) return i;
    }
    return 16;
}

const int FT_33_DURATIONS[40] = int[40](100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100);
int ft_33_frame() {
    float t = mod(GameTime * 1200000.0, 4000.0);
    for (int i = 0; i < 40; ++i) {
        t -= float(FT_33_DURATIONS[i]);
        if (t < 0.0) return i;
    }
    return 39;
}

const int FT_34_DURATIONS[7] = int[7](100,100,100,100,100,100,100);
int ft_34_frame() {
    float t = mod(GameTime * 1200000.0, 700.0);
    for (int i = 0; i < 7; ++i) {
        t -= float(FT_34_DURATIONS[i]);
        if (t < 0.0) return i;
    }
    return 6;
}

const int FT_41_DURATIONS[5] = int[5](250,250,250,250,1000);
int ft_41_frame() {
    float t = mod(GameTime * 1200000.0, 2000.0);
    for (int i = 0; i < 5; ++i) {
        t -= float(FT_41_DURATIONS[i]);
        if (t < 0.0) return i;
    }
    return 4;
}

vec4 ft_profile_process_color(vec4 inputColor) {
    ivec3 rgb = ivec3(floor(inputColor.rgb * 255.0 + 0.5));

    if (rgb.r == 254 && rgb.g == 166 && rgb.b >= 1 && rgb.b <= 17) {
        return vec4(1.0, 1.0, 1.0, ft_32_frame() == rgb.b - 1 ? inputColor.a : 0.0);
    }

    if (rgb.r == 254 && rgb.g == 167 && rgb.b >= 1 && rgb.b <= 40) {
        return vec4(1.0, 1.0, 1.0, ft_33_frame() == rgb.b - 1 ? inputColor.a : 0.0);
    }

    if (rgb.r == 254 && rgb.g == 168 && rgb.b >= 1 && rgb.b <= 7) {
        return vec4(1.0, 1.0, 1.0, ft_34_frame() == rgb.b - 1 ? inputColor.a : 0.0);
    }

    if (rgb.r == 254 && rgb.g == 169 && rgb.b >= 1 && rgb.b <= 5) {
        return vec4(1.0, 1.0, 1.0, ft_41_frame() == rgb.b - 1 ? inputColor.a : 0.0);
    }
    return inputColor;
}
